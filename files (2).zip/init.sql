-- ============================================================
-- Price Comparison Bot — Database Initialization
-- Run once: psql -U postgres -f init.sql
-- ============================================================

CREATE DATABASE price_bot
    WITH ENCODING 'UTF8'
    LC_COLLATE 'en_US.UTF-8'
    LC_CTYPE 'en_US.UTF-8'
    TEMPLATE template0;

\c price_bot

-- Enable pg_trgm for fuzzy product-name search
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ------------------------------------------------------------
-- products
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
    barcode         TEXT        PRIMARY KEY,
    product_name    TEXT        NOT NULL,
    manufacturer    TEXT
);

-- Fast exact-barcode lookups (already covered by PK)
-- Fast partial / fuzzy product-name lookups
CREATE INDEX IF NOT EXISTS idx_products_name_trgm
    ON products USING GIN (product_name gin_trgm_ops);

CREATE INDEX IF NOT EXISTS idx_products_name_lower
    ON products (lower(product_name));

-- ------------------------------------------------------------
-- branch_prices
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS branch_prices (
    id          BIGSERIAL   PRIMARY KEY,
    barcode     TEXT        NOT NULL REFERENCES products(barcode) ON DELETE CASCADE,
    chain_name  TEXT        NOT NULL,
    branch_name TEXT        NOT NULL,
    price       NUMERIC(10, 2) NOT NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_bp_barcode       ON branch_prices (barcode);
CREATE INDEX IF NOT EXISTS idx_bp_chain         ON branch_prices (chain_name);
CREATE INDEX IF NOT EXISTS idx_bp_price         ON branch_prices (price);
-- Composite: cheapest price per barcode lookups
CREATE INDEX IF NOT EXISTS idx_bp_barcode_price ON branch_prices (barcode, price);

-- ============================================================
-- Convenience view: cheapest offer per barcode
-- ============================================================
CREATE OR REPLACE VIEW cheapest_per_barcode AS
SELECT DISTINCT ON (bp.barcode)
    bp.barcode,
    p.product_name,
    p.manufacturer,
    bp.chain_name,
    bp.branch_name,
    bp.price,
    bp.updated_at
FROM branch_prices bp
JOIN products      p  ON p.barcode = bp.barcode
ORDER BY bp.barcode, bp.price ASC;
