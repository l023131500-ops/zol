# Price Comparison Bot — Setup & Deployment Guide

## Project Layout

```
price_bot/
├── db/
│   └── init.sql              # One-time DB schema creation
├── systemd/
│   └── price-bot.service     # systemd unit (auto-start + restart)
├── nginx/
│   └── price-bot.conf        # Nginx reverse proxy (optional)
├── config.py                 # Centralised settings (reads .env)
├── db.py                     # Async SQLAlchemy engine & session
├── cron_fetch.py             # Daily XML ingestion script
├── main.py                   # FastAPI app (IVR + WhatsApp endpoints)
├── requirements.txt
└── .env.example              # Copy → .env and fill in secrets
```

---

## 1 — VPS Prerequisites

```bash
# Ubuntu 22.04 / 24.04
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3.11 python3.11-venv python3-pip \
    postgresql postgresql-contrib nginx certbot python3-certbot-nginx
```

---

## 2 — PostgreSQL Setup

```bash
# Create DB user and database
sudo -u postgres psql <<'SQL'
CREATE USER price_bot_user WITH PASSWORD 'CHANGE_ME_STRONG_PASSWORD';
CREATE DATABASE price_bot OWNER price_bot_user;
GRANT ALL PRIVILEGES ON DATABASE price_bot TO price_bot_user;
SQL

# Run schema init (extensions + tables + indexes)
sudo -u postgres psql -d price_bot -f /home/ubuntu/price_bot/db/init.sql

# Verify
sudo -u postgres psql -d price_bot -c "\dt"
```

---

## 3 — Python Virtual Environment

```bash
cd /home/ubuntu
python3.11 -m venv price_bot/venv
source price_bot/venv/bin/activate
pip install --upgrade pip
pip install -r price_bot/requirements.txt
```

---

## 4 — Environment File

```bash
cp /home/ubuntu/price_bot/.env.example /home/ubuntu/price_bot/.env
nano /home/ubuntu/price_bot/.env
```

Edit at minimum:

```
DATABASE_URL=postgresql+asyncpg://price_bot_user:CHANGE_ME_STRONG_PASSWORD@localhost:5432/price_bot
```

---

## 5 — Manual First Run (seed the database)

Before starting the server, populate prices so queries return results:

```bash
cd /home/ubuntu/price_bot
source venv/bin/activate
python cron_fetch.py
# Expect several minutes of output ending with "Daily fetch done"
```

---

## 6 — Start the API Server

### Quick (foreground, for testing)

```bash
cd /home/ubuntu/price_bot
source venv/bin/activate
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

### Production (systemd)

```bash
sudo cp /home/ubuntu/price_bot/systemd/price-bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now price-bot
sudo systemctl status price-bot
```

View live logs:

```bash
sudo journalctl -u price-bot -f
```

---

## 7 — Nginx + TLS (optional but recommended)

```bash
# Install config
sudo cp /home/ubuntu/price_bot/nginx/price-bot.conf /etc/nginx/sites-available/price-bot
sudo ln -s /etc/nginx/sites-available/price-bot /etc/nginx/sites-enabled/

# Get a free TLS cert (replace domain)
sudo certbot --nginx -d your-domain.com

sudo nginx -t && sudo systemctl reload nginx
```

---

## 8 — Firewall

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
# Do NOT expose port 8000 directly; let Nginx proxy it
sudo ufw enable
```

---

## 9 — Test the Endpoints

### IVR endpoint

```bash
curl "http://localhost:8000/api/ivr/search?barcode=7290000066681"
# Expected:
# read=t-עבור קוקה קולה 1.5 ליטר, המחיר הזול ביותר הוא 6.90 שקלים ברשת שופרסל
```

### WhatsApp endpoint (barcode)

```bash
curl -X POST http://localhost:8000/api/whatsapp/search \
  -H "Content-Type: application/json" \
  -d '{"message": "7290000066681"}'
```

### WhatsApp endpoint (product name)

```bash
curl -X POST http://localhost:8000/api/whatsapp/search \
  -H "Content-Type: application/json" \
  -d '{"message": "קוקה קולה"}'
```

### Health check

```bash
curl http://localhost:8000/health
```

### Interactive docs (Swagger)

Open in browser: `http://YOUR_SERVER_IP:8000/docs`

---

## 10 — Cron / Scheduled Fetch

The APScheduler inside `main.py` fires `run_daily_job()` automatically at
the hour/minute set in `.env` (default **03:00 Asia/Jerusalem**).

To trigger a manual re-fetch without restarting the server:

```bash
# Only accessible from localhost (blocked by Nginx for public)
curl -X POST http://localhost:8000/api/admin/trigger-fetch
```

---

## 11 — Make.com (WhatsApp) Webhook Setup

1. In Make.com, add an **HTTP → Make a request** module.
2. URL: `https://your-domain.com/api/whatsapp/search`
3. Method: `POST`
4. Headers: `Content-Type: application/json`
5. Body (raw JSON):
   ```json
   {"message": "{{1.text}}"}
   ```
   where `{{1.text}}` is the incoming WhatsApp message variable.
6. The `reply` field in the JSON response is your message text to send back.

---

## 12 — Yemot Hamashiah IVR Setup

In your Yemot flow, add a **Read URL** step:

```
https://your-domain.com/api/ivr/search?barcode={barcode_variable}
```

The response starts with `read=t-` which Yemot recognises as a TTS string.

---

## Performance Notes

| Scenario | Expected latency |
|---|---|
| Barcode lookup (indexed) | < 5 ms |
| Product name fuzzy search | < 30 ms |
| Concurrent users (4 workers) | ~200 req/s |

- `branch_prices` is **truncated** daily (not deleted row-by-row) for speed.
- All heavy DB work uses `asyncpg` — no thread blocking.
- `pg_trgm` GIN index makes Hebrew fuzzy search fast even on millions of rows.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `asyncpg.exceptions.ConnectionRefusedError` | Check PostgreSQL is running: `sudo systemctl status postgresql` |
| Empty results after fetch | Check `cron_fetch.py` logs; chain URLs may have changed |
| Port 8000 not accessible | Check `ufw` and that Nginx is proxying correctly |
| IVR returns garbled Hebrew | Ensure UTF-8 encoding end-to-end; Yemot needs UTF-8 responses |
