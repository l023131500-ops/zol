"""
cron_fetch.py — Daily price-data ingestion from Israeli supermarket chains.

Sources: Price Transparency Law XML files published at
  https://prices.shufersal.co.il  (Shufersal)
  https://www.rami-levy.co.il/he/api/catalog  (Rami Levy)
  https://keshet-prices.s3.eu-west-1.amazonaws.com  (Keshet/Mega)
  https://חברות נוספות...

Run manually:   python cron_fetch.py
Run via cron:   see systemd/timer unit or APScheduler in main.py
"""
from __future__ import annotations

import asyncio
import gzip
import io
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterator

import httpx
from lxml import etree
from sqlalchemy import text
from tenacity import retry, stop_after_attempt, wait_exponential

from db import get_session

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
)
log = logging.getLogger("cron_fetch")

# ---------------------------------------------------------------------------
# Chain source definitions
# ---------------------------------------------------------------------------

@dataclass
class ChainSource:
    chain_name: str          # Display name used in branch_prices
    index_url: str           # URL that lists available price-file URLs
    file_pattern: re.Pattern # Regex to pick PriceFull files from the index
    file_type: str           # "xml_gz" | "xml" | "csv"


CHAIN_SOURCES: list[ChainSource] = [
    ChainSource(
        chain_name="שופרסל",
        index_url="https://prices.shufersal.co.il/FileObject/UpdateCategory?catID=2&storeId=0",
        file_pattern=re.compile(r"PriceFull.*?\.gz", re.IGNORECASE),
        file_type="xml_gz",
    ),
    ChainSource(
        chain_name="רמי לוי",
        index_url="https://url.retail.pe.il/api/raw/RamiLevy/?FileType=prices&MainBranch=0",
        file_pattern=re.compile(r"PriceFull.*?\.gz", re.IGNORECASE),
        file_type="xml_gz",
    ),
    ChainSource(
        chain_name="ויקטורי",
        index_url="https://matrixcatalog.co.il/NBCompetitionRegulations.aspx",
        file_pattern=re.compile(r"PriceFull.*?\.gz", re.IGNORECASE),
        file_type="xml_gz",
    ),
    ChainSource(
        chain_name="יינות ביתן",
        index_url="https://url.retail.pe.il/api/raw/YeinotBitan/?FileType=prices&MainBranch=0",
        file_pattern=re.compile(r"PriceFull.*?\.gz", re.IGNORECASE),
        file_type="xml_gz",
    ),
    ChainSource(
        chain_name="חצי חינם",
        index_url="https://url.retail.pe.il/api/raw/HaziHinam/?FileType=prices&MainBranch=0",
        file_pattern=re.compile(r"PriceFull.*?\.gz", re.IGNORECASE),
        file_type="xml_gz",
    ),
]

# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (compatible; PriceBotIL/1.0; "
        "+https://github.com/your-org/price-bot)"
    )
}
TIMEOUT = httpx.Timeout(60.0, connect=10.0)


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=2, min=4, max=30),
    reraise=True,
)
async def fetch_bytes(client: httpx.AsyncClient, url: str) -> bytes:
    resp = await client.get(url, headers=HEADERS, timeout=TIMEOUT, follow_redirects=True)
    resp.raise_for_status()
    return resp.content


async def collect_file_urls(
    client: httpx.AsyncClient,
    source: ChainSource,
) -> list[str]:
    """Parse the chain's index page and return matching file URLs."""
    try:
        body = await fetch_bytes(client, source.index_url)
    except Exception as exc:
        log.warning("Failed to fetch index for %s: %s", source.chain_name, exc)
        return []

    text_body = body.decode("utf-8", errors="replace")
    # Extract all href / src / plain URLs from the page
    raw_urls: list[str] = re.findall(
        r'https?://[^\s"\'<>]+', text_body
    )
    matched = [u for u in raw_urls if source.file_pattern.search(u)]
    log.info("%s: found %d price files", source.chain_name, len(matched))
    return matched


# ---------------------------------------------------------------------------
# XML parsing
# ---------------------------------------------------------------------------

def _decompress(raw: bytes, file_type: str) -> bytes:
    if file_type == "xml_gz":
        return gzip.decompress(raw)
    return raw


def parse_xml_prices(
    xml_bytes: bytes,
    chain_name: str,
    branch_name: str,
) -> Iterator[dict]:
    """
    Yield dicts with keys: barcode, product_name, manufacturer, price.

    Supports both Shufersal-style and Rami-Levy-style XML schemas.
    """
    try:
        root = etree.fromstring(xml_bytes)
    except etree.XMLSyntaxError as exc:
        log.warning("XML parse error (%s / %s): %s", chain_name, branch_name, exc)
        return

    # Determine item container tag (varies by chain)
    items = root.findall(".//Item") or root.findall(".//Product")
    for item in items:
        def _t(tag: str, fallback: str = "") -> str:
            el = item.find(tag)
            return (el.text or "").strip() if el is not None else fallback

        barcode = _t("ItemCode") or _t("Barcode") or _t("EAN")
        price_str = _t("ItemPrice") or _t("Price")
        product_name = _t("ItemName") or _t("ProductDescription") or _t("Name")
        manufacturer = _t("ManufacturerName") or _t("Manufacturer")

        if not barcode or not price_str or not product_name:
            continue

        try:
            price = float(price_str)
        except ValueError:
            continue

        if price <= 0:
            continue

        yield {
            "barcode": barcode,
            "product_name": product_name,
            "manufacturer": manufacturer or None,
            "chain_name": chain_name,
            "branch_name": branch_name,
            "price": price,
        }


def _branch_from_url(url: str, fallback: str = "כללי") -> str:
    """Best-effort: extract branch identifier from file URL."""
    match = re.search(r"(\d{3,6})", url)
    return match.group(1) if match else fallback


# ---------------------------------------------------------------------------
# DB operations
# ---------------------------------------------------------------------------

async def truncate_prices(session) -> None:
    await session.execute(text("TRUNCATE TABLE branch_prices RESTART IDENTITY"))
    log.info("branch_prices truncated")


async def bulk_upsert_products(session, rows: list[dict]) -> None:
    if not rows:
        return
    stmt = text("""
        INSERT INTO products (barcode, product_name, manufacturer)
        VALUES (:barcode, :product_name, :manufacturer)
        ON CONFLICT (barcode) DO NOTHING
    """)
    await session.execute(stmt, rows)


async def bulk_insert_prices(session, rows: list[dict]) -> None:
    if not rows:
        return
    stmt = text("""
        INSERT INTO branch_prices (barcode, chain_name, branch_name, price, updated_at)
        VALUES (:barcode, :chain_name, :branch_name, :price, :updated_at)
    """)
    now = datetime.now(timezone.utc)
    for r in rows:
        r["updated_at"] = now
    await session.execute(stmt, rows)


# ---------------------------------------------------------------------------
# Main ingestion pipeline
# ---------------------------------------------------------------------------

BATCH_SIZE = 5_000  # rows per DB commit


async def ingest_chain(
    client: httpx.AsyncClient,
    source: ChainSource,
    session,
) -> int:
    """Fetch, parse and insert all price files for one chain. Returns row count."""
    file_urls = await collect_file_urls(client, source)
    if not file_urls:
        return 0

    total = 0
    for url in file_urls:
        branch = _branch_from_url(url, fallback="ראשי")
        try:
            raw = await fetch_bytes(client, url)
            xml_bytes = _decompress(raw, source.file_type)
        except Exception as exc:
            log.warning("Skip %s (%s): %s", url, source.chain_name, exc)
            continue

        product_batch: list[dict] = []
        price_batch: list[dict] = []

        for row in parse_xml_prices(xml_bytes, source.chain_name, branch):
            product_batch.append(
                {
                    "barcode": row["barcode"],
                    "product_name": row["product_name"],
                    "manufacturer": row["manufacturer"],
                }
            )
            price_batch.append(
                {
                    "barcode": row["barcode"],
                    "chain_name": row["chain_name"],
                    "branch_name": row["branch_name"],
                    "price": row["price"],
                }
            )

            if len(price_batch) >= BATCH_SIZE:
                await bulk_upsert_products(session, product_batch)
                await bulk_insert_prices(session, price_batch)
                await session.commit()
                total += len(price_batch)
                log.info(
                    "  %s / branch %s — committed %d rows (running total: %d)",
                    source.chain_name, branch, len(price_batch), total,
                )
                product_batch.clear()
                price_batch.clear()

        # Flush remainder
        if price_batch:
            await bulk_upsert_products(session, product_batch)
            await bulk_insert_prices(session, price_batch)
            await session.commit()
            total += len(price_batch)

    log.info("%s ingestion complete — %d rows", source.chain_name, total)
    return total


async def run_daily_job() -> None:
    log.info("═══ Daily price fetch started ═══")
    start = datetime.now(timezone.utc)

    async with httpx.AsyncClient() as client:
        async with get_session() as session:
            await truncate_prices(session)
            await session.commit()

            grand_total = 0
            for source in CHAIN_SOURCES:
                try:
                    n = await ingest_chain(client, source, session)
                    grand_total += n
                except Exception as exc:
                    log.error("Chain %s failed: %s", source.chain_name, exc)

    elapsed = (datetime.now(timezone.utc) - start).total_seconds()
    log.info(
        "═══ Daily fetch done — %d rows in %.1fs ═══", grand_total, elapsed
    )


if __name__ == "__main__":
    asyncio.run(run_daily_job())
