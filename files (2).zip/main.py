"""
main.py — FastAPI server for the Price Comparison Bot.

Endpoints
─────────
GET  /api/ivr/search?barcode=...     → plain text for Yemot Hamashiah IVR
POST /api/whatsapp/search            → JSON {"message": "..."}  → markdown reply

Run:
    uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
"""
from __future__ import annotations

import logging
import re
from contextlib import asynccontextmanager
from typing import Any

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from cron_fetch import run_daily_job
from db import get_db

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=settings.LOG_LEVEL.upper(),
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
)
log = logging.getLogger("main")

# ── Scheduler ─────────────────────────────────────────────────────────────────
scheduler = AsyncIOScheduler(timezone="Asia/Jerusalem")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Start APScheduler on startup, shut it down on exit."""
    scheduler.add_job(
        run_daily_job,
        trigger="cron",
        hour=settings.CRON_HOUR,
        minute=settings.CRON_MINUTE,
        id="daily_price_fetch",
        replace_existing=True,
    )
    scheduler.start()
    log.info(
        "Scheduler started — daily fetch at %02d:%02d (Asia/Jerusalem)",
        settings.CRON_HOUR,
        settings.CRON_MINUTE,
    )
    yield
    scheduler.shutdown(wait=False)


app = FastAPI(
    title="Price Comparison Bot API",
    version="1.0.0",
    lifespan=lifespan,
)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _is_barcode(s: str) -> bool:
    """Return True if the string looks like a numeric barcode (EAN-8/13 etc.)."""
    return bool(re.fullmatch(r"\d{4,20}", s.strip()))


async def _fetch_cheapest_by_barcode(
    db: AsyncSession, barcode: str, limit: int = 3
) -> list[dict[str, Any]]:
    """Return up to *limit* cheapest branches for a given barcode."""
    result = await db.execute(
        text("""
            SELECT
                p.product_name,
                p.manufacturer,
                bp.chain_name,
                bp.branch_name,
                bp.price
            FROM branch_prices bp
            JOIN products p ON p.barcode = bp.barcode
            WHERE bp.barcode = :barcode
            ORDER BY bp.price ASC
            LIMIT :limit
        """),
        {"barcode": barcode, "limit": limit},
    )
    return [dict(r._mapping) for r in result.fetchall()]


async def _fetch_cheapest_by_name(
    db: AsyncSession, query: str, limit: int = 3
) -> list[dict[str, Any]]:
    """
    Fuzzy product-name search using pg_trgm similarity + LIKE fallback.
    Returns the cheapest offer per matching product (up to *limit*).
    """
    result = await db.execute(
        text("""
            WITH matched_products AS (
                SELECT barcode, product_name, manufacturer
                FROM products
                WHERE
                    product_name ILIKE '%' || :q || '%'
                    OR similarity(product_name, :q) > 0.25
                ORDER BY similarity(product_name, :q) DESC
                LIMIT 20
            ),
            cheapest AS (
                SELECT DISTINCT ON (bp.barcode)
                    mp.product_name,
                    mp.manufacturer,
                    bp.chain_name,
                    bp.branch_name,
                    bp.price,
                    bp.barcode
                FROM branch_prices bp
                JOIN matched_products mp ON mp.barcode = bp.barcode
                ORDER BY bp.barcode, bp.price ASC
            )
            SELECT product_name, manufacturer, chain_name, branch_name, price
            FROM cheapest
            ORDER BY price ASC
            LIMIT :limit
        """),
        {"q": query, "limit": limit},
    )
    return [dict(r._mapping) for r in result.fetchall()]


def _format_price(price: float | None) -> str:
    if price is None:
        return "?"
    return f"{price:,.2f}".rstrip("0").rstrip(".")


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 1 — IVR (Yemot Hamashiah)
# ─────────────────────────────────────────────────────────────────────────────

@app.get(
    "/api/ivr/search",
    response_class=PlainTextResponse,
    summary="IVR barcode lookup (Yemot Hamashiah)",
    tags=["IVR"],
)
async def ivr_search(
    barcode: str = Query(..., description="Product barcode (numeric)"),
    db: AsyncSession = Depends(get_db),
) -> str:
    """
    Query the DB for the cheapest price by barcode and return a
    Yemot-Hamashiah-compatible plain-text string.

    Format:
        read=t-עבור [product_name], המחיר הזול ביותר הוא [price] שקלים ברשת [chain_name]
    """
    barcode = barcode.strip()
    if not _is_barcode(barcode):
        return "read=t-ברקוד שגוי. אנא נסה שנית."

    rows = await _fetch_cheapest_by_barcode(db, barcode, limit=1)

    if not rows:
        return f"read=t-לא נמצא מחיר לברקוד {barcode}. אנא נסה שנית."

    row = rows[0]
    product_name = row["product_name"]
    chain_name = row["chain_name"]
    price = _format_price(row["price"])

    return (
        f"read=t-עבור {product_name}, "
        f"המחיר הזול ביותר הוא {price} שקלים ברשת {chain_name}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 2 — WhatsApp / Make.com
# ─────────────────────────────────────────────────────────────────────────────

class WhatsAppRequest(BaseModel):
    message: str


MEDALS = ["🥇", "🥈", "🥉"]


def _build_whatsapp_response(rows: list[dict], query: str) -> dict[str, str]:
    """Build a structured markdown reply for WhatsApp."""
    if not rows:
        return {
            "status": "not_found",
            "reply": (
                f"😕 *לא נמצאו תוצאות עבור:* _{query}_\n\n"
                "נסה לחפש לפי ברקוד או שם מוצר אחר."
            ),
        }

    product_name = rows[0]["product_name"]
    lines = [
        f"🛒 *{product_name}*",
        f"📊 *3 המחירים הזולים ביותר:*\n",
    ]

    for i, row in enumerate(rows[:3]):
        medal = MEDALS[i] if i < len(MEDALS) else f"{i+1}."
        price_fmt = _format_price(row["price"])
        chain = row["chain_name"]
        branch = row["branch_name"]
        lines.append(f"{medal} *{chain}* — סניף {branch}")
        lines.append(f"   💰 ₪{price_fmt}\n")

    cheapest = _format_price(rows[0]["price"])
    priciest = _format_price(rows[-1]["price"])
    if len(rows) > 1:
        try:
            diff = float(rows[-1]["price"]) - float(rows[0]["price"])
            lines.append(
                f"💡 *חיסכון פוטנציאלי:* ₪{diff:,.2f} "
                f"(בין {cheapest} ל-{priciest})"
            )
        except (TypeError, ValueError):
            pass

    lines.append("\n_מחירים מתעדכנים מדי יום_ 🔄")

    return {"status": "found", "reply": "\n".join(lines)}


@app.post(
    "/api/whatsapp/search",
    summary="WhatsApp / Make.com price search",
    tags=["WhatsApp"],
)
async def whatsapp_search(
    body: WhatsAppRequest,
    db: AsyncSession = Depends(get_db),
) -> dict[str, str]:
    """
    Accept a free-text message (barcode or partial product name).
    Returns top-3 cheapest stores in markdown format with emojis.
    """
    query = body.message.strip()
    if not query:
        raise HTTPException(status_code=400, detail="message field is empty")

    if _is_barcode(query):
        rows = await _fetch_cheapest_by_barcode(db, query, limit=3)
    else:
        rows = await _fetch_cheapest_by_name(db, query, limit=3)

    return _build_whatsapp_response(rows, query)


# ─────────────────────────────────────────────────────────────────────────────
# Health & admin endpoints
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/health", tags=["Admin"], summary="Health check")
async def health(db: AsyncSession = Depends(get_db)) -> dict:
    result = await db.execute(text("SELECT COUNT(*) FROM branch_prices"))
    count = result.scalar()
    return {"status": "ok", "branch_prices_count": count}


@app.post(
    "/api/admin/trigger-fetch",
    tags=["Admin"],
    summary="Manually trigger daily price fetch",
)
async def trigger_fetch(request: Request) -> dict:
    """
    Kick off an immediate price-fetch job (runs in background).
    Protect this endpoint with a firewall rule or an API key in production.
    """
    import asyncio

    asyncio.create_task(run_daily_job())
    return {"status": "fetch_started"}
